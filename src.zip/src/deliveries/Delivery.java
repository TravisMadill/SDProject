package deliveries;

public abstract class Delivery {
	public static final int type_Food = 1;
	public static final int type_Medical = 2;
	public static final int type_Clothing = 3;
	public static final int type_Null = 0;
}
