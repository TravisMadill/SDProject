package users.wealthgivers;

import users.Wealthgiver;

public class PropertyDonor extends Wealthgiver {

	// A special type of wealth giver prioritizing in shelters
	public PropertyDonor(String name, String address, String userID) {
		super(name, address, userID);
	}

}
