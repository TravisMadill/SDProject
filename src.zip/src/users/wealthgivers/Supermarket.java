package users.wealthgivers;

import users.Wealthgiver;

public class Supermarket extends Wealthgiver {

	// A special type of wealth giver prioritizing in food donations
	public Supermarket(String name, String address, String userID) {
		super(name, address, userID);
	}

}
