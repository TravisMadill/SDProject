package users.wealthgivers;

import users.Wealthgiver;

public class Pharmacy extends Wealthgiver {

	// A special type of wealth giver prioritizing in medical donations
	public Pharmacy(String name, String address, String userID) {
		super(name, address, userID);
	}

}
