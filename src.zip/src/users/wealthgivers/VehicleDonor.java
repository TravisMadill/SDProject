package users.wealthgivers;

import users.Wealthgiver;

public class VehicleDonor extends Wealthgiver {

	// A special type of wealth giver prioritizing in vehicle donations
	public VehicleDonor(String name, String address, String userID) {
		super(name, address, userID);
	}

}
