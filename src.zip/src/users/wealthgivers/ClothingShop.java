package users.wealthgivers;

import users.Wealthgiver;

public class ClothingShop extends Wealthgiver {

	// A special type of wealth giver prioritizing in clothing donations
	public ClothingShop(String name, String address, String userID) {
		super(name, address, userID);
	}

}
